from sklearn.cluster import AgglomerativeClustering
from ivis import Ivis
from sklearn.preprocessing import MinMaxScaler
from sklearn import datasets
import time
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
from numpy import *
import numpy as np
import pandas as pd

from munkres import Munkres,print_matrix
import argparse
parser = argparse.ArgumentParser(description='dataname')
parser.add_argument("--dataname", type=str, default="Goolam")
args = parser.parse_args()
def SC(S, k):
    # Step 1: Construct a similarity graph
    # It may be necessary to build a similarity graph based on the similarity matrix S

    # Step 2: Calculate the Laplacian matrix
    D = np.diag(np.sum(S, axis=1))  # Degree matrix
    L = D - S  # The Laplacian matrix

    # Step 3: Computing feature vectors
    eigenvalues, eigenvectors = np.linalg.eigh(L)
    indices = eigenvalues.argsort()  # The feature values are sorted
    k_smallest_eigenvectors = eigenvectors[:, indices[:k]]  # The k eigenvectors with smaller eigenvalues are selected

    # Step 4: Clustering
    kmeans = KMeans(n_clusters=k, random_state=100)
    kmeans.fit(k_smallest_eigenvectors)
    labels = kmeans.labels_
    print(adjusted_rand_score(gt, labels),normalized_mutual_info_score(gt, labels))
    # Outputs the clustering results
    return labels

# The sample point score is calculated using the manifold ranking algorithm
def CEAM(result_onehot, alpha, K):
    Yi = np.array(result_onehot)
    m = len(Yi) # m is the number of base clusterings
    n, _ = Yi[0].shape 

    Wi = []
    for o in range(m):
        Wi.append(Yi[o] @ Yi[o].T)

    Ytmp2 = np.zeros((m, n, K))

    Di = np.zeros((n, m))
    for i in range(m):
        d = 1.0 / np.sqrt(np.maximum(np.sum(Wi[i], axis=1) + m - 1, np.finfo(float).eps))
        Di[:, i] = d

    Ytmp = np.expand_dims(Yi,0).repeat(10,axis=0)
    maxiter = 10


    for j in range(m):
        for i in range(maxiter):
            for k1 in range(m):
                YY = alpha * Wi[k1].dot(Ytmp[j][k1]) + (1 - alpha) * Yi[j]

                for k2 in range(m):
                    if k2 == k1:
                        continue
                    else:
                        dd = alpha * Di[:, k1] * Di[:, k2]
                        YY = YY + np.multiply(Ytmp[j][k2], dd[:, np.newaxis])

                Ytmp2[k1, :] = YY

            Ytmp[j] = Ytmp2
    return Ytmp

def best_map(L1,L2):
	# L1 should be the labels and L2 should be the clustering number we got
	Label1 = np.unique(L1)       # Remove duplicate elements and arrange them from smallest to largest
	nClass1 = len(Label1)        # Size of the tag
	Label2 = np.unique(L2)       
	nClass2 = len(Label2)
	nClass = np.maximum(nClass1,nClass2)
	G = np.zeros((nClass,nClass))
	for i in range(nClass1):
		ind_cla1 = L1 == Label1[i]
		ind_cla1 = ind_cla1.astype(float)
		for j in range(nClass2):
			ind_cla2 = L2 == Label2[j]
			ind_cla2 = ind_cla2.astype(float)
			G[i,j] = np.sum(ind_cla2 * ind_cla1)
	m = Munkres()
	index = m.compute(-G.T)
	index = np.array(index)
	c = index[:,1]
	newL2 = np.zeros(L2.shape)
	for i in range(nClass2):
		newL2[L2 == Label2[i]] = Label1[c[i]]
	return newL2

def re_label(gt):
    gt_uni = unique(gt)
    for num in range(len(gt_uni)):
        gt[gt == gt_uni[num]] = num
    return gt 

def clustering(data, label):
    # Hierarchical clustering
    score = {'ari': [], 'nmi': []}
    for i in range(1):
        clustering = AgglomerativeClustering(n_clusters=K, affinity='euclidean', linkage='ward')
        pre = clustering.fit_predict(data)
        score['ari'].append(adjusted_rand_score(pre, label))
        score['nmi'].append(normalized_mutual_info_score(pre, label))
    print(mean(score['ari']), mean(score['nmi']))
    return pre

# Low-dimensional embeddings of different dimensions are integrated
def ensemble(data):
    n = N  # Number of samples

    # Generate base clusterings
    result = []
    for values in data.values():
        bc = clustering(values, gt)
        bc = re_label(bc)
        result.append(bc)

    # Align the base clusterings
    for i in range(M-1):
        result[i+1] = best_map(result[0], result[i+1])

    # The onehot label assignment matrix is obtained for each base clustering
    result_onehot = []
    for j in range(M):
        onehot = np.zeros((n, len(np.unique(gt))))
        for k in range(n):
            onehot[k, int(result[j][k])] = 1
        result_onehot.append(onehot)

    # The co-correlation matrix is obtained
    S = np.zeros((n, n))
    for l in range(M):
        B = result_onehot[l]
        S += np.dot(B, B.T)
    S /= M

    return S, result_onehot, result
dataname = args.dataname


#Load gene expression matrix, label information
fea = pd.read_csv('./data/'+dataname+'.csv',header=None)
gt = pd.read_csv('./data/'+dataname+'_gt.csv',header=None)
K = gt.nunique()
K = K[0]
gt = gt.unstack()
N = fea.shape[0]

#Generate base clusterings
M = 10
X = fea
latent_var = {}
data_use=[]
data_use = ['Goolam','Usoskin','Chen','Wang_lung','mouse_ES_cell','Manno','Ting','Baronh','sim1','sim2','sim3','sim4','sim5']

if dataname in data_use:
    for index in range(M):
        model = Ivis()
        model = model.load_model('./model/'+dataname+str(index+1))
        X_scaled = MinMaxScaler().fit_transform(X)
        embeddings = model.transform(X_scaled)
        latent_var[dataname+str(index)] = embeddings
    #Ensemble
    S, result_onehot, _ = ensemble(latent_var)
    result = SC(S,K)
    # Open a file to write data to
    with open('./result/'+dataname+'.txt', 'w') as file:
        for item in result:
            file.write("%s\n" % item)
    print(result)
else:
    for index in range(M):
        model = Ivis(embedding_dims =2000,k=index+20,batch_size=64)
        X_scaled = MinMaxScaler().fit_transform(X)
        embeddings = model.fit_transform(X_scaled)
        model.save_model('./model/'+ dataname + str(index+1), save_format='h5', overwrite=True)
        latent_var[dataname+str(index)] = embeddings

    #Ensemble
    S, result_onehot, _ = ensemble(latent_var)
    result = SC(S,K)

    #Multiway graph calculation score
    score = CEAM(result_onehot, alpha=0.85, K=K)
    print(score)
    #Selecting representative units
    repe_index = np.zeros((N, K))  # The representative element selection matrix
    pre_repe_num = 128 # The number of pre-representative elements is selected for each base clustering
    repe_num = 128 # The number of representative elements
    repe_cell = np.zeros((repe_num, K))  # Representative element matrix

    # Construct the representative element indication matrix
    for l in range(M):
        ew = score[l][l].copy()
        for i in range(pre_repe_num):
            index = np.argmax(ew, axis = 0)
            #print(index)  # Display the representative meta-labels selected by each base clustering
            for j in range(K):
                repe_index[index[j], j] += 1  # If a sample point is selected as the representative element of a cluster by a base cluster, +1 will be placed at the corresponding position of the representative element indication matrix
                ew[index[j], j] = 0
    repe_index = repe_index / (np.expand_dims(np.sum(repe_index ,axis = 1), 1).repeat(K, axis=1) + np.finfo(np.float32).eps)  # 归一化修正
    #print(repe_index)

    # Select representative element
    index_tmp = repe_index.copy()
    for t in range(repe_num):
        repe_cell[t, :] = np.argmax(index_tmp, axis = 0)
        for z in range(K):
            index_tmp[int(repe_cell[t, :][z]), z] = 0
    #print(repe_cell)

    #Extracting submatrix
    repe_cell = repe_cell.astype(int)
    X_new = pd.DataFrame()
    for i in range(repe_cell.shape[0]):
        for j in range(repe_cell.shape[1]):
            # Gets the line number of the current element
            row_index = repe_cell[i, j]
            X_new = pd.concat([X_new, X.iloc[row_index:row_index+1]])

    #Optimizing weights
    latent_var_new = {}
    for index in range(M):
        model_exist = model.load_model('./model/'+dataname+str(index+1))
        X_scaled = MinMaxScaler().fit_transform(X_new)
        model_exist.fit(X_scaled)
        X_scaled = MinMaxScaler().fit_transform(X)
        embeddings = model.transform(X_scaled)
        latent_var_new[dataname+str(index)] = embeddings

    print(latent_var_new)

    #Ensemble
    S, result_onehot, _ = ensemble(latent_var_new)
    result = SC(S,K)
    # Open a file to write data to
    with open('./result/'+dataname+'.txt', 'w') as file:
        for item in result:
            file.write("%s\n" % item)
    print(result)
